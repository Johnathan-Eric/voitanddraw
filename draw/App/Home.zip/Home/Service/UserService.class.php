<?php
// 本类由系统自动生成，仅供测试用途
namespace Home\Service;
//use Think\Controller;
class UserService{
	public function index(){
		echo "Hello, world!";
	}
	
    public function login(){
        echo 'login event';
    }
    public function logout(){
        echo 'logout event';
    }
}