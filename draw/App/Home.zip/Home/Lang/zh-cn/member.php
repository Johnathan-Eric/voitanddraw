<?php
return array(
		'UPLOAD_DATA_EMPTY'		=> '您还未上传%s',
		'YOU_ARE_NOT_UPLOAD'	=> '此 %s 并非你所上传',
		'AUTH_BODY_PHOTO'		=> '身体免冠照',
		'AUTH_IDCARD_FACADE'	=> '身份证正面照',
		'AUTH_IDCARD_OBVERSE'	=> '身份证背面照',
		
);

