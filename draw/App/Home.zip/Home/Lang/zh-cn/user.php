<?php
return array(
		'CLOSE_REG' 	=> '本站已经关闭新用户注册功能！',
		'USER_LOGIN'	=> '用户登陆',
		'USER_BIND'		=> '帐户绑定',
		'USER_LOCK'		=> '帐户锁定',
		'USER_REGISTER'	=> '帐户锁定',
		'USER_AUDIT'	=> '您的帐户正在审核中',
		'PROFILE'		=> '完善用户资料',
		
		'AUDIT_STATUS'		=> '审核状态',
		'AUDIT_FAIL'		=> '审核未通过',
		'REGISTER_SUCCESS'	=> '审核未通过',
		
);

