<?php
class Commonconfig{
	public static $open_AppID='wxe8517f6c045140f4';
	public static $EncodingAesKey='R1I8ET2Uy78XQ18E1uu8EeuzeT858ix1TzE1x2II8q1';
	public static $Token='GtrhLn4RU94h5aR9RaRqqruuXRnqUurA';
	public static $open_AppID_Secrect='e6788d47dcae3bd8559cab2e5e60ccd3';
	public static $domain = 'http://mingpian.9daogu.cn';
	public static $modifydomain = 'mingpian.9daogu.cn';

}